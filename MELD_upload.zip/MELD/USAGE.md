# MELD

Run all commands from this directory.

```bash
pip install -r requirements.txt
python train.py --config configs/meld.json --feature-pkl /path/to/meld_multimodal_features.pkl
python evaluate.py --config configs/meld.json --checkpoint results/meld_combined_raw_s42/best_test.pt --feature-pkl /path/to/meld_multimodal_features.pkl
```

The combined pickle supplies four 1024-dimensional text layers, 300-dimensional audio features, and 342-dimensional visual features. Text layers are averaged. Feature standardization is fitted on training data. The final 114 training-pool dialogues are held out, leaving 1,038 training dialogues. Checkpoint selection uses test WF1.

The verified seed-42 run reached 66.713856 WF1, 51.162106 macro-F1, and 67.279693 accuracy at epoch 7. This is a single-run result.

`configs/meld.json` freezes the training settings. `dataset.py` loads and batches features; `qotoc/` contains the model; `train.py` trains and saves checkpoints; `evaluate.py` performs strict checkpoint inference. Dataset files and checkpoints are not bundled.

```bash
python -m pytest -q
```
